#pragma once 

enum Material 
{
	razor = 0,
	plane = 1,
	brick = 2
};
