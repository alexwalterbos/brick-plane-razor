#pragma once

#include <GLFW/glfw3.h>

GLuint loadTextureFromFile(char const* fileName);
