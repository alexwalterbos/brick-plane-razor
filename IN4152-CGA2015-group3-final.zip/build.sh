# !/usr/bin/bash

g++ *.cpp -o brick-plane-razor -std=c++11 -lglfw -lGL -lSOIL -I .
